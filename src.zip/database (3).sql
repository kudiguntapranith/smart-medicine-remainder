-- Smart Medicine Reminder Database Schema (Clean MySQL 8.x - Zero Warnings, Zero Errors)

CREATE DATABASE IF NOT EXISTS smart_medicine_db;
USE smart_medicine_db;

-- Disable foreign key checks for safe recreation
SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables
DROP TABLE IF EXISTS medicine_history;
DROP TABLE IF EXISTS medicine_schedules;
DROP TABLE IF EXISTS medicines;
DROP TABLE IF EXISTS users;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Medicines Table (Using standard TINYINT without display width (1) to prevent Warning 1681)
CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    dosage VARCHAR(50) NOT NULL,
    frequency_type VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    notes TEXT,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_medicines_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Medicine Schedules Table
CREATE TABLE medicine_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id INT NOT NULL,
    reminder_time TIME NOT NULL,
    CONSTRAINT fk_schedules_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Medicine History Table
CREATE TABLE medicine_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    medicine_id INT NOT NULL,
    schedule_id INT NOT NULL,
    scheduled_date DATE NOT NULL,
    scheduled_time TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    action_time TIMESTAMP NULL DEFAULT NULL,
    CONSTRAINT fk_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_history_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
    CONSTRAINT fk_history_schedule FOREIGN KEY (schedule_id) REFERENCES medicine_schedules(id) ON DELETE CASCADE,
    CONSTRAINT unique_dose UNIQUE (user_id, medicine_id, schedule_id, scheduled_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Insert Sample Demo User
INSERT INTO users (id, username, password_hash, full_name) VALUES 
(1, 'demo', '$2a$10$wO8K/.N3Y5wAFlm6N3H5y.V3v.M.E3C.Q/e1Hl2S3z.K3X3G3G3G3', 'Demo User');
